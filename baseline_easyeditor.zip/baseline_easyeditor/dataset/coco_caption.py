"""
 Copyright (c) 2022, salesforce.com, inc.
 All rights reserved.
 SPDX-License-Identifier: BSD-3-Clause
 For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/BSD-3-Clause
"""

import os
from collections import OrderedDict

from .processor.base_dataset import BaseDataset
from .processor.blip_processors import BlipImageEvalProcessor
from ..trainer.utils import dict_to
from PIL import Image
import random
import typing
import torch
import transformers
from tqdm import tqdm
from copy import deepcopy
from transformers import AutoTokenizer
from ..trainer.mPLUG_Owl2.mplug_owl2.mm_utils import tokenizer_image_token, process_images

class CaptionDataset(BaseDataset):
    def __init__(self, data_dir: str, size:  typing.Optional[int] = None, config=None, no_image=False, hop=None, *args, **kwargs):
        """
        vis_root (string): Root directory of images (e.g. coco/images/)
        ann_root (string): directory to store the annotation file
        """
        # get tokenizer and vis_processor
        if config.model_class == "Blip2OPT":
            vis_processor = BlipImageEvalProcessor(image_size=364, mean=None, std=None)
        elif config.model_class == "LLaVA":
            vis_processor = transformers.CLIPImageProcessor.from_pretrained("openai/clip-vit-large-patch14-336")
        elif config.model_class ==  "qwen-vl":
                vis_processor = BlipImageEvalProcessor(image_size=448, mean=None, std=None)
        elif "owl-2" in config.model_name.lower():
            from transformers.models.clip.image_processing_clip import CLIPImageProcessor
            vis_processor = CLIPImageProcessor.from_pretrained(config.name, trust_remote_code=True)
        else:
            raise NotImplementedError("unknown model class")

        if (config is not None and hasattr(config, 'tokenizer_name')):
            tok_name = (
                config.tokenizer_name
                if config.tokenizer_name is not None
                else config.name
            )
            tokenizer = getattr(transformers, config.tokenizer_class).from_pretrained(
                tok_name, trust_remote_code=True
            )      
            if config.tokenizer_class == "QWenTokenizer":
                tokenizer = AutoTokenizer.from_pretrained(config.name, trust_remote_code=True, pad_token='<|endoftext|>')
            elif config.model_name == "owl-2":
                tokenizer = AutoTokenizer.from_pretrained(config.name, use_fast=False, trust_remote_code=True)
            else:
                tokenizer = getattr(transformers, config.tokenizer_class).from_pretrained(
                    tok_name, trust_remote_code=True
                )            
            if tokenizer.pad_token == None or tokenizer.pad_token == '':
                tokenizer.pad_token = tokenizer.eos_token        
            if tokenizer.pad_token == None or tokenizer.pad_token == '':
                tokenizer.pad_token = tokenizer.eos_token  
                
        vis_root = config.coco_image
        rephrase_root = config.rephrase_image
        
        super().__init__(vis_processor, vis_root, rephrase_root, [data_dir])

        self.config = config
        self.tok = tokenizer
        self.max_length = 32
        self.hop = hop

        self.prompt = "Question: {} Short answer: "

        def constrcution_path_answer(orginal_question,image_answer, hop):
            path_answer_list = []
            # 处理第一个 triple，答案在 post 字段
            triple1 = hop.get("triple1", {})
            question_list = []
            question_list.append([orginal_question]*3)
            path_answer_list.append([image_answer]*3)

        
        
            #这里要处理一下的，图片也要问问、


            # 处理后续 triple，答案在 answer + answer_ali
            i = 2
            while True:
                triple_key = f"triple{i}"
                triple = hop.get(triple_key)
                if not triple:
                    break
                # 答案为 answer + answer_ali
                question_list.append(triple.get("rewrite_question", ""))
                answer_list = [triple.get("answer", "")]
                answer_list.extend(triple.get("answer_ali", []))
                path_answer_list.append(answer_list)
                i += 1
            answer_last = path_answer_list[-1]

            return question_list, path_answer_list, answer_last
    

        data = []
        if size is not None:
            self.annotation = self.annotation[:size]
            # assert int(hop) in [1, 2, 3, 4], "hop should be 1, 2, 3, or 4"
            # port_types = ['', '1-hop', '2-hop', '3-hop', '4-hop']
            # port_type = port_types[int(hop)]
        for record in tqdm(self.annotation, ncols=120, desc='Loading Data'):
            if record['alt'] == "":
                continue
            if hop and 'port_new' not in record.keys():
                continue
            
            image_path = os.path.join(self.vis_root, record["image"])
            rephrase_image_path = os.path.join(self.rephrase_root, record["image_rephrase"])
            locality_image_path = os.path.join(self.vis_root, record['m_loc'])
            
            # image = Image.open(image_path).convert("RGB")
            # rephrase_image = Image.open(rephrase_image_path).convert("RGB")
            # locality_image = Image.open(locality_image_path).convert("RGB")

            # image = self.vis_processor(image)
            # rephrase_image = self.vis_processor(rephrase_image)  
            # locality_image = self.vis_processor(locality_image)  
            
                      
            item = {
                'prompt': record['src'],
                'pred': record['pred'],
                'target': record['alt'],
                'rephrase_prompt': record['rephrase'],
                # 'image': image,
                # 'image_rephrase': rephrase_image,
                'image': image_path,
                'image_rephrase': rephrase_image_path,
                'cond': "{} >> {} || {}".format(
                    record['pred'],
                    record['alt'],
                    record['src']
                )
            }
            
            item['locality_prompt'] = record['loc']
            item['locality_ground_truth'] = record['loc_ans']
            
            # item['multimodal_locality_image'] = locality_image
            item['multimodal_locality_image'] = locality_image_path

            item['multimodal_locality_prompt'] = record['m_loc_q']
            item['multimodal_locality_ground_truth'] = record['m_loc_a']
            all_item = {}
            
            if 'port_new' in record.keys():

                for index,ports in enumerate(record['port_new']):
                    new_item = {}
                    new_item['portability_prompt'] = []
                    new_item['portability_ground_truth'] = []
                    new_item['portability_ground_truth_ali'] = []  # <-- 添加初始化
                    new_item['port_question_path'] = []            # <-- 建议也初始化
                    new_item['port_answer_path'] = [] 
                    last_triple = ports["triple{0}".format(index+2)]
                    # print("last_triple", last_triple)
                    
                    
                    question_list, current_answer_all_path,last_answer =  constrcution_path_answer(record['src'],record['alt'], ports)
                    # print("question_list", question_list)
                    # print("current_answer_all_path", current_answer_all_path)
                    # print("last_answer", last_answer)

                    
                    
                    # find_hop = True
                    port_q = last_triple['rewrite_question']
                    port_a = last_triple['answer']
                    port_last_answer_ali = last_answer
                    port_answer_path = current_answer_all_path
                    port_question_path=question_list

                    new_item['portability_prompt'].append(port_q)
                    new_item['portability_ground_truth'].append(port_a)
                    new_item['portability_ground_truth_ali'].append(port_last_answer_ali)
                    new_item['port_question_path'].append(port_question_path[:-1])
                    new_item['port_answer_path'].append(port_answer_path[:-1])  # 去掉最后一个答案路径
                    port_type_name = ports['port_type']            
                    all_item[port_type_name] = new_item
                item["port_all_item"] = all_item
            # else:
            #     continue
            data.append(item)
            
        # if size is not None:
        #     data = data[:size]        
        self._data = data
        self.no_image = no_image
    


    def __getitem__(self, index):
        if self.no_image:
            return self._data[index]

        data = deepcopy(self._data[index])        
        # load image
        image_path = data['image']
        rephrase_image_path = data['image_rephrase']
        locality_image_path = data['multimodal_locality_image']
        
        image = Image.open(image_path).convert("RGB")
        rephrase_image = Image.open(rephrase_image_path).convert("RGB")
        locality_image = Image.open(locality_image_path).convert("RGB")
        
        if self.config.model_class == "Blip2OPT":
            image = self.vis_processor(image)
            rephrase_image = self.vis_processor(rephrase_image)
            locality_image = self.vis_processor(locality_image)
        elif self.config.model_class == "LLaVA":
            image = self.vis_processor(image, return_tensors='pt')['pixel_values'].to(dtype=torch.float16)
            rephrase_image = self.vis_processor(rephrase_image, return_tensors='pt')['pixel_values'].to(dtype=torch.float16)
            locality_image = self.vis_processor(locality_image, return_tensors='pt')['pixel_values'].to(dtype=torch.float16)
        elif self.config.model_class == "qwen-vl":
            image = os.path.join(self.vis_root, image_path)
            rephrase_image = os.path.join(self.rephrase_root, rephrase_image_path)
            locality_image = os.path.join(self.vis_root, locality_image_path)
        elif self.config.model_name == "owl-2":
            _image = Image.open(image_path).convert('RGB')
            max_edge = max(_image.size) 
            image = process_images([_image.resize((max_edge, max_edge))], self.vis_processor)
            _image = Image.open(rephrase_image_path).convert('RGB')
            max_edge = max(_image.size) 
            rephrase_image = process_images([_image.resize((max_edge, max_edge))], self.vis_processor)

            _image = Image.open(locality_image_path).convert('RGB')
            max_edge = max(_image.size) 
            locality_image = process_images([_image.resize((max_edge, max_edge))], self.vis_processor)
        else:
            raise NotImplementedError

        data['image'] = image
        data['image_rephrase'] = rephrase_image
        data['multimodal_locality_image'] = locality_image
        return data
    
    def __len__(self):
        return len(self._data)

    def collate_fn(self, batch):
        src = [b['prompt'] for b in batch]
        trg = [b['target'] for b in batch]
        cond = [b['cond'] for b in batch]
        rephrase = [b['rephrase_prompt'] for b in batch]
        image = [b['image'] for b in batch]
        image_rephrase = [b['image_rephrase'] for b in batch]
        loc_q = [b["locality_prompt"] for b in batch]
        loc_a = [b["locality_ground_truth"] for b in batch]
        m_loc_image = [b['multimodal_locality_image'] for b in batch]
        m_loc_q = [b['multimodal_locality_prompt'] for b in batch]
        m_loc_a = [b['multimodal_locality_ground_truth'] for b in batch]
        
        # edit_inner
        edit_inner = {}
        edit_inner['image'] = torch.stack(image, dim=0) if ("qwen-vl" not in self.config.model_name and "owl-2" not in self.config.model_name) else image
        edit_inner['text_input'] = [" ".join([s, t]) for s, t in zip(src, trg)]
        edit_inner['labels'] = trg
        edit_inner['prompts_len'] = [len(self.tok.encode(s)) for s in src]
        edit_inner['labels'] = torch.nn.utils.rnn.pad_sequence(
            [torch.tensor(self.tok.encode(s)) for s in trg],
            batch_first=True,
            padding_value=self.tok.pad_token_id if self.tok.pad_token_id is not None else 0
        )

        # edit_outer
        edit_outer = {}
        edit_outer['image'] = torch.stack(image, dim=0) if ("qwen-vl" not in self.config.model_name and "owl-2" not in self.config.model_name) else image
        edit_outer['text_input'] = [" ".join([r, t]) for r, t in zip(rephrase, trg)]
        edit_outer['labels'] = trg
        edit_outer['prompts_len'] = [len(self.tok.encode(r)) for r in rephrase]
        edit_outer['labels'] = self.tok(
            trg,
            return_tensors="pt",
            padding=True,
            truncation=True,
        )["input_ids"]

        # edit_outer_image
        edit_outer_image = {}
        edit_outer_image['image'] = torch.stack(image_rephrase, dim=0) if ("qwen-vl" not in self.config.model_name and "owl-2" not in self.config.model_name) else image
        edit_outer_image['text_input'] = [" ".join([s, t]) for s, t in zip(src, trg)]
        edit_outer_image['labels'] = trg
        edit_outer_image['prompts_len'] = [len(self.tok.encode(s)) for s in src]
        edit_outer_image['labels'] = self.tok(
            trg,
            return_tensors="pt",
            padding=True,
            truncation=True,
        )["input_ids"]

        # loc
        loc = {}
        loc['image'] = torch.zeros(1, 3, 448, 448) if "owl-2" in self.config.model_name else None
        loc['text_input'] = [" ".join([q, a]) for q, a in zip(loc_q, loc_a)]
        loc['labels'] = loc_a
        loc['prompts_len'] = [len(self.tok.encode(q)) for q in loc_q]
        loc['labels'] = self.tok(
            loc_a,
            return_tensors="pt",
            padding=True,
            truncation=True,
        )["input_ids"]

        # m_loc
        loc_image = {}
        loc_image['image'] = torch.stack(m_loc_image, dim=0)
        loc_image['text_input'] = [" ".join([q, a]) for q, a in zip(m_loc_q, m_loc_a)]
        loc_image['labels'] = m_loc_a
        loc_image['prompts_len'] = [len(self.tok.encode(q)) for q in m_loc_q]
        loc_image['labels'] = self.tok(
            m_loc_a,
            return_tensors="pt",
            padding=True,
            truncation=True,
        )["input_ids"]

        # cond
        
        cond = self.tok(
            cond,
            return_tensors="pt",
            padding=True,
            max_length=self.max_length,
            truncation=True,
        ).to(self.config.device)



        edit_ports = {}
        # print("edit_inner",edit_inner)
        
        #这里999 表示的是 rephrase 的图片.
        

        if 'port_all_item' in batch[0].keys():
            key_all_item = batch[0]['port_all_item']
            for key, all_item in key_all_item.items():
                for port_q, port_a, port_alis, port_ques_path, port_ans_path in zip(
                    all_item['portability_prompt'],
                    all_item['portability_ground_truth'],
                    all_item['portability_ground_truth_ali'],
                    all_item['port_question_path'],
                    all_item['port_answer_path']
                ):
                    port = {}
                    
                    # port['image'] = torch.stack(image, dim=0)
                    if  int(self.hop) == 999:
                        port['image'] = torch.stack(image_rephrase, dim=0) if ("qwen-vl" not in self.config.model_name and "owl-2" not in self.config.model_name) else image_rephrase
                    elif int(self.hop) == 100:
                        port['image'] = torch.stack(image, dim=0) if ("qwen-vl" not in self.config.model_name and "owl-2" not in self.config.model_name) else image
                    else:
                        print("hop is not 999 or 100, please check the config.hop")
                  
                    port['text_input'] = port_q
                    port['answer_text'] = port_a
                    port['prompts_len'] = [len(self.tok.encode(q)) for q in port_q]
                    # 这里 port_a 可能是单个字符串，也可能是列表，假设是单个字符串
                    port['labels'] = torch.tensor([self.tok.encode(port_a)])
                    port['ques_path_inputs'] = port_ques_path
                    port['answer_ali'] = port_alis
                    port["port_ans_path"] = port_ans_path
                edit_ports[key]= port

            # print("edit_ports", edit_ports)
            # exit()
        
        
        batch = {
            "edit_inner": edit_inner,
            "edit_outer": edit_outer,
            "edit_outer_image": edit_outer_image,
            "loc": loc,
            "loc_image": loc_image,
            'port': edit_ports,
            "cond": cond,

        }
        # print("batch",batch)
        # exit()
        

    

        return dict_to(batch, self.config.device)
