"""
Contains evaluation utilities for pytorch-based rewriting methods.
To use, simply call `compute_rewrite_quality_zsre` with the
appropriate arguments, which returns a dictionary containing them.
"""

import typing
from itertools import chain
from typing import List, Optional

import numpy as np
import torch
# from sklearn.feature_extraction.text import TfidfVectorizer
from transformers import AutoTokenizer
from ..util import HyperParams
from .portability_evaluate import compute_portability_quality
from .evaluate_utils import (
    test_seq2seq_batch_prediction_acc, 
    test_batch_prediction_acc, 
    test_prediction_acc,
    test_generation_quality, 
    PPL,
    kl_loc_loss,
    es_sent
)

def compute_edit_quality(
    model,
    model_name,
    hparams: HyperParams,
    tok: AutoTokenizer,
    record: typing.Dict,
    device,
    eval_metric: str = 'token_em',
    test_generation = False
) -> typing.Dict:
    """
    Given a rewritten model, computes generalization and specificity metrics for
    the desired rewrite (passed in via the CounterFact dataset record). Returns a
    dictionary containing those metrics.

    :param model: Rewritten model
    :param tok: Tokenizer
    :param record: CounterFact dataset record
    :paran snips: ???
    :param vec: ???
    :return: Dictionary containing rewriting metrics
    """

    # First, unpack rewrite evaluation record.
    target_new, ground_truth = (
        record[x] for x in ["target_new", "ground_truth"]
    )

    rewrite_prompts = record["prompt"]
    rephrase_prompts = record["rephrase_prompt"] if 'rephrase_prompt' in record.keys() else None
    ret = compute_rewrite_or_rephrase_quality(model, model_name, hparams, tok,
                                              rewrite_prompts, target_new, device=device, eval_metric=eval_metric)

    ret['locality'] = {}
    ret['portability'] = {}
    if rephrase_prompts is not None:
        ret.update(
            compute_rewrite_or_rephrase_quality(model, model_name, hparams, tok,
                                                rephrase_prompts, target_new, device=device, test_rephrase=True, eval_metric=eval_metric)
        )

    if 'locality' in record.keys() and any(record['locality']):
        for locality_key in record['locality'].keys():
            ret['locality'].update(
                compute_locality_quality(model, model_name, hparams, tok, locality_key,
                                         record['locality'][locality_key]['prompt'],
                                         record['locality'][locality_key]['ground_truth'], device=device)
            )
    if 'portability' in record.keys() and any(record['portability']):
        for portability_key in record['portability'].keys():
            ret['portability'].update(
                compute_portability_quality(model, model_name, hparams, tok, portability_key,
                                            record['portability'][portability_key]['prompt'],
                                            record['portability'][portability_key]['ground_truth'], device=device)
            )
    if  test_generation:
        ret['fluency'] = test_generation_quality(model=model,tok=tok,prefixes=rewrite_prompts if isinstance(rewrite_prompts,list) else [rewrite_prompts,], max_out_len=100)
    return ret




def verify_gold_path(entities,  path):
    if len(entities) != len(path):
        return False
    for i in range(len(path)):
        if entities[i].lower().strip() == "" or len(entities[i].lower().strip())<=3 or not any(c.isalpha() for c in entities[i].lower()):
            return False
        if any(entities[i].lower() in p.lower() for p in path[i]):
            continue
        else:
            return False
    return True


def compute_rewrite_or_rephrase_quality(
    model,
    model_name,
    hparams: HyperParams,
    tok: AutoTokenizer,
    prompt: str,
    target_new: str,
    device,
    test_rephrase: bool = False,
    eval_metric: str = 'token_em'
) -> typing.Dict:
    
    if not test_rephrase:
        key = 'rewrite'
    else:
        key = 'rephrase'
    if eval_metric == 'ppl':
        ppl = PPL(model, tok, prompt, target_new, device)
        ret = {
            f"{key}_ppl": ppl
        }
    else:
        if 't5' in model_name.lower():
            acc = test_seq2seq_batch_prediction_acc(model, tok, hparams, prompt, target_new, device)
        else:
            acc = test_prediction_acc(model, tok, hparams, prompt, target_new, device)
        ret = {
            f"{key}_acc": acc
        }
    return ret

def compute_locality_quality(
    model,
    model_name,
    hparams: HyperParams,
    tok: AutoTokenizer,
    locality_key: str,
    prompt: str,
    locality_ground_truth: str,
    device,
) -> typing.Dict:

    if 't5' in model_name.lower():
        loc_tokens = test_seq2seq_batch_prediction_acc(model, tok, hparams, prompt, locality_ground_truth, device, locality=True)
    else:
        loc_tokens = test_prediction_acc(model, tok, hparams, prompt, locality_ground_truth, device, locality=True)

    if type(loc_tokens) is not list:
        loc_tokens = [loc_tokens,]

    ret = {
        f"{locality_key}_output": loc_tokens
    }
    return ret

def compute_icl_edit_quality(
    model,
    model_name,
    hparams: HyperParams,
    tok: AutoTokenizer,
    icl_examples,
    record: typing.Dict,
    device,
    pre_edit: bool = False
) -> typing.Dict:
    """
    Given a rewritten model, computes generalization and specificity metrics for
    the desired rewrite (passed in via the CounterFact dataset record). Returns a
    dictionary containing those metrics.

    :param model: Rewritten model
    :param tok: Tokenizer
    :param record: CounterFact dataset record
    :param snips: ???
    :param vec: ???
    :return: Dictionary containing rewriting metrics
    """

    # First, unpack rewrite evaluation record.
    target_new, ground_truth = (
        record[x] for x in ["target_new", "ground_truth"]
    )
    prompt = record["prompt"]
    rephrase = record["rephrase_prompt"] if 'rephrase_prompt' in record.keys() else None
    new_fact = f'New Fact: {prompt} {target_new}\nPrompt: {prompt}'

    if pre_edit:
        edit_acc = icl_lm_eval(model, model_name, hparams, tok, icl_examples,
                                       target_new, prompt)
    else:
        edit_acc = icl_lm_eval(model, model_name, hparams, tok, icl_examples,
                                              target_new, new_fact)
    ret = {
        f"rewrite_acc": edit_acc
    }
    ret['locality'] = {}
    ret['portability'] = {}
    if rephrase is not None:
        rephrase_acc = icl_lm_eval(model, model_name, hparams, tok, icl_examples,
                               target_new, f'New Fact: {prompt} {target_new}\nPrompt: {rephrase}')
        ret['rephrase_acc'] = rephrase_acc

    if 'locality' in record.keys() and any(record['locality']):
        for locality_key in record['locality'].keys():
            pre_neighbor = icl_lm_eval(model, model_name, hparams, tok, [''], record['locality'][locality_key]['ground_truth'],
                                       f"New Fact: {prompt} {target_new}\nPrompt: {record['locality'][locality_key]['prompt']}", neighborhood=True)
            post_neighbor = icl_lm_eval(model, model_name, hparams, tok, icl_examples, record['locality'][locality_key]['ground_truth'],
                                        f"New Fact: {prompt} {target_new}\nPrompt: {record['locality'][locality_key]['prompt']}", neighborhood=True)
            if type(pre_neighbor) is not list:
                pre_neighbor = [pre_neighbor, ]
            if type(post_neighbor) is not list:
                post_neighbor = [post_neighbor, ]
            assert len(pre_neighbor) == len(post_neighbor)

            ret['locality'][f'{locality_key}_acc'] = np.mean(np.equal(pre_neighbor, post_neighbor))
    # Form a list of lists of prefixes to test.
    if 'portability' in record.keys() and any(record['portability']):
        for portability_key in record['portability'].keys():
            if pre_edit:
                portability_acc = icl_lm_eval(model, model_name, hparams, tok, icl_examples, record['portability'][portability_key]['ground_truth'],
                                              record['portability'][portability_key]['prompt'])
            else:
                portability_acc = icl_lm_eval(model, model_name, hparams, tok, icl_examples, record['portability'][portability_key]['ground_truth'],
                                              f"New Fact: {prompt} {target_new}\nPrompt: {record['portability'][portability_key]['prompt']}")
            ret['portability'][f'{portability_key}_acc'] = portability_acc
    return ret

def icl_lm_eval(
        model,
        model_name,
        hparams: HyperParams,
        tokenizer,
        icl_examples,
        target,
        x,
        neighborhood=False
)-> typing.Dict:
    device = torch.device(f'cuda:{hparams.device}')
    if 't5' in model_name.lower():
        target_len = len(tokenizer.encode(target))
        target_ids = tokenizer(f'{x} {target}', return_tensors='pt')['input_ids'].to(device)
        encodings = tokenizer(''.join(icl_examples), return_tensors='pt')
        input_ids = encodings['input_ids'].to(device)
        attention_mask = encodings['attention_mask'].to(device)
        with torch.no_grad():
            logits = model(input_ids=input_ids, attention_mask=attention_mask, labels=target_ids).logits
            ans = torch.argmax(logits, dim=-1)[:,-target_len:-1].squeeze()
            target_ids = target_ids[:,-target_len:-1]
            if neighborhood:
                return ans.squeeze().detach().cpu().numpy().tolist()
            return torch.mean((ans == target_ids.to(ans.device).squeeze()).float(), dim=-1).detach().cpu().numpy().tolist()
    elif 'llama' in model_name.lower():
        target_ids = tokenizer(target, return_tensors='pt')['input_ids'].to(device)
        encodings = tokenizer(''.join(icl_examples) + f'{x} {target}', return_tensors='pt')
        input_ids = encodings['input_ids'].to(device)
        attention_mask = encodings['attention_mask'].to(device)
        logits = model(input_ids=input_ids, attention_mask=attention_mask).logits
        ans = torch.argmax(logits, dim=-1)[:,-target_ids.size(1):-1].squeeze()
        target_ids = target_ids[:,1:]   
        if neighborhood:
            return ans.squeeze().detach().cpu().numpy().tolist()
        return torch.mean((ans == target_ids.to(ans.device).squeeze()).float(), dim=-1).detach().cpu().numpy().tolist()        
    else:
        target_ids = tokenizer(' ' + target + '\n', return_tensors='pt')['input_ids'].to(device)
        encodings = tokenizer(''.join(icl_examples) + f'{x} {target}', return_tensors='pt')
        input_ids = encodings['input_ids'].to(device)
        attention_mask = encodings['attention_mask'].to(device)
        logits = model(input_ids=input_ids, attention_mask=attention_mask).logits
        ans = torch.argmax(logits, dim=-1)[:,-target_ids.size(1):-1].squeeze()
        target_ids = target_ids[:,:-1]
        if neighborhood:
            return ans.squeeze().detach().cpu().numpy().tolist()
        return torch.mean((ans == target_ids.to(ans.device).squeeze()).float(), dim=-1).detach().cpu().numpy().tolist()

def compute_icl_multimodal_edit_quality(
    model,
    model_name,
    hparams: HyperParams,
    tok: AutoTokenizer,
    # vis_tok,
    icl_examples,
    record: typing.Dict,
    device,
    pre_edit: bool = False
) -> typing.Dict:
    """
    Given a rewritten model, computes generalization and specificity metrics for
    the desired rewrite (passed in via the CounterFact dataset record). Returns a
    dictionary containing those metrics.

    :param model: Rewritten model
    :param tok: Tokenizer
    :param record: CounterFact dataset record
    :param snips: ???
    :param vec: ???
    :return: Dictionary containing rewriting metrics
    """
    vis_root = hparams.coco_image
    rephrase_root = hparams.rephrase_image
    # First, unpack rewrite evaluation record.
    target = record["target"]
    prompt = record["prompt"]
    image = record["image"] if record["image"].is_cuda else record["image"].to(hparams.device)
    rephrase = record["rephrase_prompt"] if 'rephrase_prompt' in record.keys() else None
    rephrase_image = record["image_rephrase"] if 'image_rephrase' in record.keys() else None
    if rephrase_image is not None:
        rephrase_image = rephrase_image if rephrase_image.is_cuda else rephrase_image.to(hparams.device)

    ret = {}
    ######### portability #########
    
    if pre_edit:
        ret['portability_acc'] = None
    else:
        if "port_all_item" in record.keys():
            port_acc = 0
            for port_q, port_a in zip(record['portability_prompt'], record['portability_ground_truth']):
                

                port_acc_i, pred_targ_ids = icl_multimodal_lm_eval(model, model_name, hparams, tok, icl_examples, 
                                                    port_a, f'New Fact: {prompt} {target}\nPrompt: {port_q}', image)
                port_acc += port_acc_i
            ret['portability_acc'] = port_acc/len(record['portability_prompt'])
            ret['pred_ids'] = pred_targ_ids[0].tolist()
            ret['targ_ids'] = pred_targ_ids[1].tolist()
    ######### portability #########
    # print("ret['portability_acc']", ret['portability_acc'])
    # exit()

    return ret


def compute_icl_multimodal_edit_quality_myself(model,
    model_name,
    hparams: HyperParams,
    tok: AutoTokenizer,
    # vis_tok,
    icl_examples,
    record: typing.Dict,
    hop,
    pre_edit: bool = False
) -> typing.Dict:
    
    
    target = record["target"]
    pred = record["pred"]
    prompt = record["prompt"]
    image = record["image"] if record["image"].is_cuda else record["image"].to(hparams.device)
    rephrase = record["rephrase_prompt"] if 'rephrase_prompt' in record.keys() else None
    rephrase_image = record["image_rephrase"] if 'image_rephrase' in record.keys() else None
    if rephrase_image is not None:
        rephrase_image = rephrase_image if rephrase_image.is_cuda else rephrase_image.to(hparams.device)
   

    if int(hop) ==100:
        image = image
    elif int(hop)==999:
        image = rephrase_image
    else:
        print("Hop is not 100 or 999, please check the hop value.")
        exit()
    

    ret = {}
    ######### portability #########
    cor = tot = 0
    ver_cor = 0
    cor_list = [0,0,0,0]
    ver_cor_list = [0,0,0,0]
    tot_list = [0,0,0,0]
    info_dict = {}
    # print("---------------------Processing record...----------------------------")
    # print("==================="*20)
    # print(record)
    # exit()    
    details = []  # 新增：用于保存每条的详细信息
    if pre_edit:
        ret['portability_acc'] = None
    else:
        if record['port_all_item'] is not None:
            port_acc = 0
            # print("record['port_all_item']",record['port_all_item'])
            # exit()
            # 遍历所有 hop
            for hop_name, port in record['port_all_item'].items():
                
                tot += 1
                print("port---------",port)
      
                hop_num = int(hop_name.split('-')[0])  # 1-hop -> 1, 2-hop -> 2
                hop_idx = hop_num - 1  # index: 0, 1, 2, 3
                tot_list[hop_idx] += 1  # 统计总数
                with torch.no_grad():
                    found_ans = gold_path = False
                    port_labels = port["portability_ground_truth"][0]
                    print("port_labels",port_labels)

                    targ_token = port_labels
                    # print(port)
                    # exit()
            
                    # targ_token = tok.encode(port_labels)
                    print("------------------this is main result-------------------")
                    for index, each_question in enumerate(port["portability_prompt"][0]):
                     
                        port_q = each_question
                        print("each_question",each_question)
                        # print(prompt)
                        # print(port_q)
            
                        # print(f'New Fact: {prompt} {target}\nPrompt: {port_q}')
                        new_fact = f'Fact: {prompt} {pred}\nPrompt: {port_q}'   ####记得 这里的 pred 表示没有编辑
                        # new_fact = f'New Fact: {prompt} {target}\nPrompt: {port_q}'   ####记得 这里的 target 表示编辑
                        # new_fact = f"Prompt: {port_q}"
                        icl_examples = []  #这样子设置应该是原始的。
                        # print(target)
                        # print("port_q",port_q)
                        # exit()
                        # exit()
                        
                        pred_token, targ_token = icl_multimodal_lm_eval_my_self(model, model_name, hparams, tok, icl_examples, 
                                                   targ_token, new_fact, image)
                        
                        print(f"Predicted: {pred_token}, Target: {targ_token}")

                        details.append({
                            "question": each_question,
                            "target": targ_token,
                            "output": pred_token
                        })
                       
                        if pred_token.strip() == "" or len(pred_token.strip())<=3 or not any(c.isalnum() for c in pred_token):
                            found_ans = False
                            continue
                  
                        if any(pred_token.lower() in k.lower() for k in port['portability_ground_truth_ali'][0]):
                            if not found_ans:
                                cor += 1
                                cor_list[hop_idx] += 1
                                found_ans = True
                                info_dict['nll/{0}hop_path_pred_ids'.format(hop_idx)] = port['port_question_path']

                        if found_ans==True:
                            if port['port_question_path']==[]:
                                # ver_cor += 1
                                # ver_cor_list[hop_idx] += 1
                                break
                            else:
                                print("-------------------this is sub result-------------------")

                                path_answer_predict = []
                                for i, sub_question in enumerate(port['port_question_path'][0]):
                                    if index >= len(sub_question):
                                        new_index =0
                                    else:
                                        new_index = index    
                                    sub_question = sub_question[new_index]
                                    
                                    sub_answer = port["port_answer_path"][0][i][0]
                                    # new_sub_question = f'New Fact: {prompt} {pred}\nPrompt: {sub_question}'
                                    new_sub_question = f'Fact: {prompt} {pred}\nPrompt: {sub_question}'

                                    # new_sub_question = f'Prompt: {sub_question}'

                                   
                                    generated_sub_ids,_ = icl_multimodal_lm_eval_my_self(model, model_name, hparams, tok, icl_examples, 
                                                   sub_answer, new_sub_question, image)
                             
                                    sub_pred = generated_sub_ids
                                    path_answer_predict.append(sub_pred)
                                    # 新增：保存子问题
                                    details.append({
                                        "question": sub_question,
                                        "target": sub_answer,
                                        "output": sub_pred
                                    })
                                    print({
                                        "question": sub_question,
                                        "target": sub_answer,
                                        "output": sub_pred
                                    })
                                    

                                print("Path_answer_predict",path_answer_predict)
                                print(f"Gold Path: {port['port_answer_path'][0]}")
                                gold_path = verify_gold_path(path_answer_predict, port['port_answer_path'][0])
                                if gold_path:
                                    ver_cor += 1
                                    ver_cor_list[hop_idx] += 1
                                    info_dict['nll/{0}hop_path_pred_ids'.format(hop_idx)] = path_answer_predict
                                    break
                    info_dict['nll/{0}hop_path_ground_ids'.format(hop_idx)] = port['port_answer_path'][0]
    
            print("--------------------Cureent_item--------------------------")
            if int(tot)==0:
                info_dict['Acc'] = 0
                info_dict['Hop-Acc'] = 0
            else:

                info_dict['Acc'] = cor / tot
                info_dict['Hop-Acc'] = ver_cor / tot

            info_dict['nll/1-hop-tot'] = f'1-hop-tot = {tot_list[0]} 1-hop-cor = {cor_list[0]} 1-hop-acc = {ver_cor_list[0]}'
            info_dict['nll/2-hop-tot'] = f'2-hop-tot = {tot_list[1]} 2-hop-cor = {cor_list[1]} 2-hop-acc = {ver_cor_list[1]}'
            info_dict['nll/3-hop-tot'] = f'3-hop-tot = {tot_list[2]} 3-hop-cor = {cor_list[2]} 3-hop-acc = {ver_cor_list[2]}'
            info_dict['nll/4-hop-tot'] = f'4-hop-tot = {tot_list[3]} 4-hop-cor = {cor_list[3]} 4-hop-acc = {ver_cor_list[3]}'

        info_dict["details"] = details  # 新增：保存所有详细信息

        return cor,ver_cor,tot,cor_list,ver_cor_list,tot_list,info_dict
        







def icl_multimodal_lm_eval(
        model,
        model_name,
        hparams: HyperParams,
        tokenizer,
        icl_examples,
        target,
        x,
        image,
        neighborhood=False
)-> typing.Dict:
    # 获取设备
    device = torch.device(f'cuda:{hparams.device}')
    
    # 准备多模态编辑
    samples = prepare_multimodal_edit(hparams, tokenizer, target, [''.join(icl_examples) + f'{x}'], image) 
    # print(samples)
    # print("aaaaaaaaaaaaaaa"*30)
    # print("bbbbbbbbbbbbbbbb"*40)
    compute_multimodal_edit_quality(model, samples)
    # print("bbbbbbbbbbbbbbbb"*40)
    # 计算多模态编辑质量
    return compute_multimodal_edit_quality(model, samples)

def  iterative_generate(model, prompt, pixel_values, labels, prompt_len,tok, max_new_tokens=None):
        with torch.no_grad():
            """
            用 forward 方法逐步生成文本，直到生成长度等于 labels。
            """
            model.train(False)
            device = f"{model.device}"
            input_ids =tok(prompt, return_tensors="pt")["input_ids"].to(device)
            generated = input_ids.clone()
            cur_prompt = prompt
            if max_new_tokens is None:
                max_new_tokens = labels.shape[1]  # +1 for the initial input_ids length
            for _ in range(max_new_tokens):
                # decode当前已生成的内容，拼接到原始prompt后
                cur_text = tok.decode(generated[0], skip_special_tokens=True)
                # 这里你可以选择只拼接新生成的部分，也可以直接用cur_text
                inputs = {
                    "image": pixel_values,
                    "text_input": [cur_text],  # 用当前生成的文本
                    "prompts_len": [generated.shape[1]],  # 当前长度
                    "labels":labels,
                }
     
                
                    
                outputs = model(inputs)
                logits = outputs.logits if hasattr(outputs, "logits") else outputs
                next_token_logits = logits[:, -1, :]
                next_token_id = torch.argmax(next_token_logits, dim=-1, keepdim=True)
                generated = torch.cat([generated, next_token_id], dim=-1)
        return generated[:, input_ids.shape[1]:]  # 只返回新生成部分

def icl_multimodal_lm_eval_my_self(
        model,
        model_name,
        hparams: HyperParams,
        tokenizer,
        icl_examples,
        target,
        x,
        image,
        neighborhood=False
)-> typing.Dict:
    # 获取设备
    device = torch.device(f'cuda:{hparams.device}')
    
    # 准备多模态编辑
    
    samples = prepare_multimodal_edit_my_self(hparams, tokenizer, target, [''.join(icl_examples) + f'{x}'], image) 

 
    each_question = samples['text_input'][0]
    port = samples

    with torch.no_grad():
        generated_ids = iterative_generate(
                            model, each_question, port["image"], port["labels"], port['prompts_len'],tokenizer
                        )

        # port_labels = port["labels"]
        pred_token = tokenizer.decode(generated_ids[0].tolist(), skip_special_tokens=True).strip()
        
        # targ_token = tokenizer.decode(port_labels[0].tolist(), skip_special_tokens=True)
        # print(f"Predicted: {pred_token}, Target: {targ_token}")
   
    return pred_token, target



def icl_multimodal_loc_logits(
        model,
        model_name,
        hparams: HyperParams,
        tokenizer,
        icl_examples,
        target,
        x,
        image,
        neighborhood=False
)-> typing.Dict:    
    # 准备多模态编辑
    batch = prepare_multimodal_edit(hparams, tokenizer, target, [''.join(icl_examples) + f'{x}'], image) 
    
    # 不计算梯度
    with torch.no_grad():
        # 获取模型输出
        outputs = model(batch)
        # 判断输出类型
        if isinstance(outputs, torch.Tensor):
            # 如果输出是张量，则直接获取
            logits = outputs.detach().cpu()
        else:
            # 如果输出是模型输出，则获取logits
            logits = outputs.logits.detach().cpu()    
        # targ = outputs.labels.detach().cpu()
        # 获取标签
        targ = batch["labels"].cpu()
    # 判断logits维度
    if logits.dim() == 3:
        # 如果logits维度为3，则去掉最后一个维度
        logits = logits[:, :-1]
        # targ = targ[:, 1:]
        # 获取logits中与targ维度相同的部分
        logits = logits[:, -targ.shape[1]:]
    else:
        # 如果logits维度不为3，则抛出异常
        raise ValueError("logits should have 3 dimensions")
    # 返回logits
    return logits

def prepare_multimodal_edit(hparams,
                            tok,
                            target,
                            prompts,
                            image):
    if isinstance(target, str):
        target = [target,]
    if isinstance(prompts, str):
        prompts = [prompts,]
    if image is not None and len(image.shape) == 3:
        image = image.unsqueeze(0)
    text_input = [prompt_ + ' ' + target_ for prompt_, target_ in zip(prompts, target)]
    
    if hparams.model_name == 'minigpt4' or hparams.model_name == 'llava':
        prompts_len = [len(tok.encode(prompt, add_special_tokens=False)) for prompt in prompts]
        target = tok(target, add_special_tokens=False, return_tensors="pt",)["input_ids"]
    else:
        prompts_len = [len(tok.encode(prompt,)) for prompt in prompts]  
        target = tok([' ' + target_ if target_[0] != ' ' else target_ for target_ in target], add_special_tokens=False, return_tensors="pt",)["input_ids"]
        
    ret = {
        'text_input': text_input,
        'image': image,
        'labels': target,
        'prompts_len': prompts_len        
    } 
    return ret



def prepare_multimodal_edit_my_self(hparams,
                            tok,
                            target,
                            prompts,
                            image):
    if isinstance(target, str):
        target = [target,]
    if isinstance(prompts, str):
        prompts = [prompts,]
    if image is not None and len(image.shape) == 3:
        image = image.unsqueeze(0)
    text_input = [prompt_ for prompt_, target_ in zip(prompts, target)]
    
    if hparams.model_name == 'minigpt4' or hparams.model_name == 'llava':
        prompts_len = [len(tok.encode(prompt, add_special_tokens=False)) for prompt in prompts]
        target = tok(target, add_special_tokens=False, return_tensors="pt",)["input_ids"]
    else:
        prompts_len = [len(tok.encode(prompt,)) for prompt in prompts]  
        target = tok([' ' + target_ if target_[0] != ' ' else target_ for target_ in target], add_special_tokens=False, return_tensors="pt",)["input_ids"]
        
    ret = {
        'text_input': text_input,
        'image': image,
        'labels': target,
        'prompts_len': prompts_len        
    } 
    return ret


def compute_multimodal_edit_quality(model, batch):
    
    with torch.no_grad():

        outputs = model(batch)

        if isinstance(outputs, torch.Tensor):
            logits = outputs.detach().cpu()
        else:
            logits = outputs.logits.detach().cpu()    
        # targ = outputs.labels.detach().cpu()
        targ = batch["labels"].cpu()
    if logits.dim() == 3:
        logits = logits[:, :-1]
        # targ = targ[:, 1:]
        logits = logits[:, -targ.shape[1]:]
    mask = targ != -100
    targ[~mask] = 0
    pred_ids = logits.argmax(-1).masked_fill(~mask, 0).detach().cpu()
    correct = pred_ids == targ
    correct = correct & mask
    num_non_padding = mask.sum().float().item()
    acc = correct.sum() / num_non_padding
    
    return acc, (pred_ids.numpy(), targ.numpy())
  
def compute_multimodal_edit_quality_demo(model, batch):
    
    with torch.no_grad():
        outputs = model(batch)
        if isinstance(outputs, torch.Tensor):
            logits = outputs.detach().cpu()
        else:
            logits = outputs.logits.detach().cpu()    
        # targ = outputs.labels.detach().cpu()
        targ = batch["labels"].cpu()
    if logits.dim() == 3:
        logits = logits[:, :-1]
        # targ = targ[:, 1:]
        logits = logits[:, -targ.shape[1]:]
    mask = targ != -100
    targ[~mask] = 0
    pred_ids = logits.argmax(-1).masked_fill(~mask, 0).detach().cpu()
    correct = pred_ids == targ
    correct = correct & mask
    num_non_padding = mask.sum().float().item()
    acc = correct.sum() / num_non_padding
    
    return acc, pred_ids.numpy(), logits

def compute_multimodal_edit_results(
    model,
    model_name,
    hparams: HyperParams,
    tok: AutoTokenizer,
    record: typing.Dict,
    device
) -> typing.Dict:
    """
    Given a rewritten model, computes generalization and specificity metrics for
    the desired rewrite (passed in via the CounterFact dataset record). Returns a
    dictionary containing those metrics.

    :param model: Rewritten model
    :param tok: Tokenizer
    :param record: CounterFact dataset record
    :paran snips: ???
    :param vec: ???
    :return: Dictionary containing rewriting metrics
    """
    ret = {}
    # First, unpack rewrite evaluation record.
    
    target = record["target"]
    rewrite_prompts = record["prompt"]
    image = record["image"]
    
    edit_inner = prepare_multimodal_edit(hparams, tok, target, rewrite_prompts, image)
    ret['rewrite_acc'], _ = compute_multimodal_edit_quality(model, edit_inner)
    
    if "rephrase_prompt" in record.keys():
        rephrase_prompts = record["rephrase_prompt"]
        edit_outer = prepare_multimodal_edit(hparams, tok, target, rephrase_prompts, image)
        ret['rephrase_acc'], _ = compute_multimodal_edit_quality(model, edit_outer)
        
    if "image_rephrase" in record.keys():
        rephrase_image = record["image_rephrase"]
        edit_image_outer = prepare_multimodal_edit(hparams, tok, target, rewrite_prompts, rephrase_image) 
        ret['image_rephrase_acc'], _ = compute_multimodal_edit_quality(model, edit_image_outer)

    if 'locality_prompt' in record.keys():
        locality_prompt = record["locality_prompt"]
        locality_ground_truth = record["locality_ground_truth"]
        locality = prepare_multimodal_edit(hparams, tok, locality_ground_truth, locality_prompt, None)
        _, ret['locality_output'] = compute_multimodal_edit_quality(model, locality)
        
    if 'multimodal_locality_prompt' in record.keys():
        m_loc_prompt = record["multimodal_locality_prompt"]
        m_loc_ground_truth = record["multimodal_locality_ground_truth"]
        m_loc_image = record["multimodal_locality_image"]
        m_locality = prepare_multimodal_edit(hparams, tok, m_loc_ground_truth, m_loc_prompt, m_loc_image)
        _, ret['multimodal_locality_output'] = compute_multimodal_edit_quality(model, m_locality)
    # Form a list of lists of prefixes to test.

    return ret
  
def compute_multimodal_edit_results_demo(
    model,
    model_name,
    hparams: HyperParams,
    tok: AutoTokenizer,
    record: typing.Dict,
    device
) -> typing.Dict:
    """
    Given a rewritten model, computes generalization and specificity metrics for
    the desired rewrite (passed in via the CounterFact dataset record). Returns a
    dictionary containing those metrics.

    :param model: Rewritten model
    :param tok: Tokenizer
    :param record: CounterFact dataset record
    :paran snips: ???
    :param vec: ???
    :return: Dictionary containing rewriting metrics
    """
    ret = {}
    # First, unpack rewrite evaluation record.
    
    target = record["target"]
    rewrite_prompts = record["prompt"]
    image = record["image"]
    
    edit_inner = prepare_multimodal_edit(hparams, tok, target, rewrite_prompts, image)
    ret['rewrite_acc'], _, logits = compute_multimodal_edit_quality_demo(model, edit_inner)
    
    if "rephrase_prompt" in record.keys():
        rephrase_prompts = record["rephrase_prompt"]
        edit_outer = prepare_multimodal_edit(hparams, tok, target, rephrase_prompts, image)
        ret['rephrase_acc'], _ = compute_multimodal_edit_quality(model, edit_outer)
        
    if "image_rephrase" in record.keys():
        rephrase_image = record["image_rephrase"]
        edit_image_outer = prepare_multimodal_edit(hparams, tok, target, rewrite_prompts, rephrase_image) 
        ret['image_rephrase_acc'], _ = compute_multimodal_edit_quality(model, edit_image_outer)

    if 'locality_prompt' in record.keys():
        locality_prompt = record["locality_prompt"]
        locality_ground_truth = record["locality_ground_truth"]
        locality = prepare_multimodal_edit(hparams, tok, locality_ground_truth, locality_prompt, None)
        _, ret['locality_output'] = compute_multimodal_edit_quality(model, locality)
        
    if 'multimodal_locality_prompt' in record.keys():
        m_loc_prompt = record["multimodal_locality_prompt"]
        m_loc_ground_truth = record["multimodal_locality_ground_truth"]
        m_loc_image = record["multimodal_locality_image"]
        m_locality = prepare_multimodal_edit(hparams, tok, m_loc_ground_truth, m_loc_prompt, m_loc_image)
        _, ret['multimodal_locality_output'] = compute_multimodal_edit_quality(model, m_locality)
    # Form a list of lists of prefixes to test.

    return ret, logits


    prompt_tok = tok(
        prompt,
        padding=True,
        truncation=True,
        max_length=hparams.max_length,
        return_tensors="pt",
    ).to(f"cuda:{device}")

    trg_tok = tok(
        target,
        padding=True,
        truncation=True,
        max_length=hparams.max_length,
        return_tensors="pt",
    ).to(f"cuda:{device}")

    prompt_tok['labels'] = trg_tok['input_ids']
    # prompt_tok['decoder_attention_mask'] = trg_tok['attention_mask']


    with torch.no_grad():
        outputs = model(**prompt_tok)
        if type(outputs) is torch.Tensor:
            logits = outputs
        else:
            logits = outputs.logits

        assert logits.size(1) == trg_tok['input_ids'].size(1)
        ans = torch.argmax(logits, dim=-1)
        if locality:
            return ans.squeeze().detach().cpu().numpy().tolist()

        return torch.mean((trg_tok['input_ids'][:,:-1] == ans[:,:-1]).float(), dim=-1).detach().cpu().numpy().tolist()[0]

def compute_sent_metric(
    model,
    edited_model,
    model_name,
    hparams: HyperParams,
    tok: AutoTokenizer,
    metric_kwargs: typing.Dict,
    device,
    test_generation=True
    ):
    
    if "llama" not in model_name:
        raise NotImplementedError("currently only support for llama")
        
    def get_edit_labels(ids, prompts=None):
        labels = ids.clone()
        labels[labels == tok.pad_token_id] = -100
        return labels
        
    same_mask = torch.tensor([i == o for i, o in zip(metric_kwargs["inner_target"], metric_kwargs["all_target"])], device=device)
    edit_toks = {
        f"{k1}_{k2}": v2.to(device)
        for k1, v1 in {
            "inner": metric_kwargs["inner_all_qa"],
            "outer": metric_kwargs["outer_all_qa"],
        }.items()
        for k2, v2 in tok(
            v1,
            return_tensors="pt",
            padding=True,
            max_length=128,
            truncation=True,
        ).items()
    }
    for key in ["inner", "outer"]:
        value = edit_toks[f"{key}_input_ids"]
        mask = [([True] * value.shape[-1])] * value.shape[0]
        for i in range(value.shape[0]):
            sep_idx = list(value[i]).index(tok.convert_tokens_to_ids("</s>"))
            for j in range(sep_idx): #连带</s>一块mask掉
                mask[i][j] = False
        edit_toks[key + "_q_mask"] = torch.tensor(mask).to(device)

    with torch.no_grad():
        inner_base_logits = model(
            input_ids=edit_toks["inner_input_ids"],
            attention_mask=edit_toks["inner_attention_mask"],   
        )["logits"]
        inner_edit_logits = edited_model(
            input_ids=edit_toks["inner_input_ids"],
            attention_mask=edit_toks["inner_attention_mask"],   
        )["logits"]
        
        outer_base_logits = model(
            input_ids=edit_toks["outer_input_ids"],
            attention_mask=edit_toks["outer_attention_mask"],   
        )["logits"]
        outer_edit_logits = edited_model(
            input_ids=edit_toks["outer_input_ids"],
            attention_mask=edit_toks["outer_attention_mask"],   
        )["logits"]
    
    result = {
        "es": es_sent(inner_base_logits, inner_edit_logits, edit_toks["inner_q_mask"], get_edit_labels(edit_toks["inner_input_ids"]), same_mask).item(),
        "dd": kl_loc_loss(outer_base_logits, outer_edit_logits, edit_toks["outer_q_mask"]).item(),
    }
    if  test_generation:
        result['fluency'] = test_generation_quality(model=model,tok=tok,prefixes=metric_kwargs["inner_q"] if isinstance(metric_kwargs["inner_q"],list) else [metric_kwargs["inner_q"],], max_out_len=100)
    return result