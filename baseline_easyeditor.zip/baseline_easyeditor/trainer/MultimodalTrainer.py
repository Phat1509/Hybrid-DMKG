from .BaseTrainer import *
import json
import logging
import os
import shutil
import tempfile
import time

import torch
from .losses import kl_loc_loss
from omegaconf import OmegaConf
from torch.utils.data import Dataset
from .utils import (
    EarlyStopper,
    RunningStatAverager,
    _logits,
    formatted_timestamp,
    safe_backward,
    time_delta_seconds,
)
from tqdm import tqdm
from transformers import AutoTokenizer

LOG = logging.getLogger(__name__)


class MultimodalTrainer(BaseTrainer):
    def __init__(self, config, train_set: Dataset, val_set: Dataset):
        super().__init__(config, train_set, val_set)

        if hasattr(self.model, "edit_lrs") and not self.config.eval_only:
            self.lr_opt = self.OptimizerClass([self.model.edit_lrs], config.lr_lr)
            if self.archive is not None:
                self.lr_opt.load_state_dict(self.archive["lr_opt"])
        else:
            self.lr_opt = None

        if hasattr(self.config, "ft"):
            if getattr(self.config.ft, "use_locality", False):
                batch = next(self.edit_gen)
                self.model.loc_ids = batch["loc"]["input_ids"]
                self.model.loc_masks = batch["loc"]["attention_mask"]
        if (config is not None and hasattr(config, 'tokenizer_name')):
            tok_name = (
                config.tokenizer_name
                if config.tokenizer_name is not None
                else config.name
            )
            tokenizer = getattr(transformers, config.tokenizer_class).from_pretrained(
                tok_name, trust_remote_code=True
            )            
            if tokenizer.pad_token == None or tokenizer.pad_token == '':
                tokenizer.pad_token = tokenizer.eos_token  
                    
        self.config = config
        self.tok = tokenizer
        self.edit_number = 10


    def generat_answer(self, model, prompts,targets,pixel_values):
        print(prompts)
        print(targets)
        print("------"*20)
        
        prompts, targets = [prompts,], [targets,]
        for prompt, target_new in zip(prompts, targets):
            results_token = []
            target_new_tokens = self.tok.encode(target_new)
            prompt_tok = self.tok(
                prompt,
                return_tensors="pt",
            ).to(f"cuda:{self.config.device}")
            generate_kwargs = {
                "input_ids": prompt_tok["input_ids"],
                "image": pixel_values,
                "max_new_tokens": len(target_new_tokens),
                "pad_token_id": self.tok.eos_token_id,
                "do_sample": False,
                "use_cache": False,
            }


            gen_token = model.generate(**generate_kwargs)
            generated_text = self.tok.decode(gen_token[0], skip_special_tokens=True)
            print("生成文本:", generated_text)

    def  iterative_generate(self, model, prompt, pixel_values, labels, prompt_len, max_new_tokens=None):
        """
        用 forward 方法逐步生成文本，直到生成长度等于 labels。
        """
        with torch.no_grad():
            device = f"cuda:{self.config.device}"
            input_ids = self.tok(prompt, return_tensors="pt")["input_ids"].to(device)
            attention_mask = (input_ids != self.tok.pad_token_id)  # bool 类型
            # 强制 attention_mask 为 bool 类型，防止后续被转成 half
            attention_mask = attention_mask.bool()
            generated = input_ids.clone()
            cur_prompt = prompt
            if max_new_tokens is None:
                max_new_tokens = labels.shape[1]
            for _ in range(max_new_tokens):
                cur_text = self.tok.decode(generated[0], skip_special_tokens=True)
                inputs = {
                    "image": pixel_values,
                    "text_input": [cur_text],
                    "prompts_len": [generated.shape[1]],
                    "labels": labels,
                }
                # 再次确保传入模型前是 bool 类型
                if "attention_mask" in inputs:
                    # 先转回cpu再转bool再转回device，防止半精度污染
                    inputs["attention_mask"] = inputs["attention_mask"].to(torch.bool).to(device)
                outputs = model(inputs)
                logits = outputs.logits if hasattr(outputs, "logits") else outputs
                next_token_logits = logits[:, -1, :]
                next_token_id = torch.argmax(next_token_logits, dim=-1, keepdim=True)
                generated = torch.cat([generated, next_token_id], dim=-1)
        return generated[:, input_ids.shape[1]:]  # 只返回新生成部分




    def verify_gold_path(self, entities,  path):
        if len(entities) != len(path):
            return False
        for i in range(len(path)):
            if entities[i].lower().strip() == "" or len(entities[i].lower().strip())<=3 or not any(c.isalpha() for c in entities[i].lower()):
                return False
            if any(entities[i].lower() in  p.lower() for p in path[i]):
                continue
            else:
                return False
        return True






    def edit_step(self, batch, training: bool):
   
        self.model.train(training)
        self.original_model.train(training)
        # Do the edit
        start = time.time()
        
        
        edited_model, model_info = self.model.edit(batch["edit_inner"], batch["cond"])
        
        edit_time = time.time() - start

        l_total, l_edit, l_loc, l_base = 0, 0, 0, 0
        info_dict = {}

        ################ portability #################
        cor = tot = 0
        ver_cor = 0
        cor_list = [0,0,0,0]
        ver_cor_list = [0,0,0,0]
        tot_list = [0,0,0,0]
        info_dict = {}
        if batch['port'] is not None:
            port_acc = 0
            # 遍历所有 hop
            for hop_name, port in batch['port'].items():
                tot += 1

                print(f"-------------------Processing {hop_name}...----------------------------")
                print(port['answer_ali'])
                # hop_name: '1-hop', '2-hop', ...
                hop_num = int(hop_name.split('-')[0])  # 1-hop -> 1, 2-hop -> 2
                hop_idx = hop_num - 1  # index: 0, 1, 2, 3
                tot_list[hop_idx] += 1  # 统计总数
                with torch.no_grad():
                    found_ans = gold_path = False
                    for index, each_question in enumerate(port["text_input"]):
                        print(f"Processing question {index + 1}/{len(port['text_input'])} for {hop_name}...")
                        print(f"Question: {each_question}")

                        # 每个问题的答案是否已经找到
                        generated_ids = self.iterative_generate(
                            edited_model, each_question, port["image"], port["labels"], port['prompts_len'][index]
                        )
                        port_labels = port["labels"]
                        pred_token = self.tok.decode(generated_ids[0].tolist(), skip_special_tokens=True).strip()
                        targ_token = self.tok.decode(port_labels[0].tolist(), skip_special_tokens=True)
                        print(f"Predicted: {pred_token}, Target: {targ_token}")
                        print(each_question)
                        
                        # 如果pred_token只有空格、为空，或者不包含任何字母和数字，判为错误
                        if pred_token.lower().strip() == "" or not any(c.isalpha() for c in pred_token):
                            found_ans = False
                            continue
                        if any(pred_token.lower() in k.lower() for k in port['answer_ali']):
                            if not found_ans:
                                cor += 1
                                cor_list[hop_idx] += 1
                                found_ans = True
                                info_dict['nll/{0}hop_path_pred_ids'.format(hop_idx)] = port['ques_path_inputs']

                        if found_ans==True:
                            if port['ques_path_inputs']==[]:
                                ver_cor += 1
                                ver_cor_list[hop_idx] += 1
                                break
                            else:
                        # 如果有路径问题，进行路径验证
                                path_answer_predict = []
                                for i, sub_question in enumerate(port['ques_path_inputs']):
                                    print(sub_question)
                                    # exit()
                                    sub_question = sub_question[index]
                                    print("sub_question",sub_question)

                                    
                                    sub_answer_ids = self.tok.encode(port["port_ans_path"][i][0])
                                    sub_answer = torch.tensor([sub_answer_ids]).to(generated_ids.device)
                                    print("sub_answer",sub_answer)
                                    print(port["port_ans_path"][i][0])
                                    # sub_question = "What is the primary language spoken in the country where the location shown in the image is situated?"
                                    generated_sub_ids = self.iterative_generate(
                                        edited_model, sub_question, port["image"], sub_answer, []
                                    )

                                    print("Prediction for sub-question:", self.tok.decode(generated_sub_ids[0].tolist(), skip_special_tokens=True).strip())
                                    print("===="*30)
                                    # exit()
                                    path_answer_predict.append(self.tok.decode(generated_sub_ids[0].tolist(), skip_special_tokens=True).strip())

                                print("Path_answer_predict",path_answer_predict)
                                print(f"Gold Path: {port['port_ans_path']}")
                                gold_path = self.verify_gold_path(path_answer_predict, port["port_ans_path"])
                                if gold_path:
                                    ver_cor += 1
                                    ver_cor_list[hop_idx] += 1
                                    info_dict['nll/{0}hop_path_pred_ids'.format(hop_idx)] = path_answer_predict
                                    break
                info_dict['nll/{0}hop_path_ground_ids'.format(hop_idx)] = port['port_ans_path']
           
                print(f'Acc = {cor / tot} ({cor} / {tot})')
                print(f'Hop-Acc = {ver_cor / tot} ({ver_cor} / {tot})')
                print(f'1-hop-tot = {tot_list[0]} 1-hop-cor = {cor_list[0]} 1-hop-acc = {ver_cor_list[0]}')
                print(f'2-hop-tot = {tot_list[1]} 2-hop-cor = {cor_list[1]} 2-hop-acc = {ver_cor_list[1]}')
                print(f'3-hop-tot = {tot_list[2]} 3-hop-cor = {cor_list[2]} 3-hop-acc = {ver_cor_list[2]}')
                print(f'4-hop-tot = {tot_list[3]} 4-hop-cor = {cor_list[3]} 4-hop-acc = {ver_cor_list[3]}')
                print("--------------------Cureent_item--------------------------")
                if int(tot) == 0:
                    info_dict['Acc'] = 0.0
                    info_dict['Hop-Acc'] = 0.0
                else:
                    info_dict['Acc'] = cor / tot
                    info_dict['Hop-Acc'] = ver_cor / tot
                info_dict['nll/1-hop-tot'] = f'1-hop-tot = {tot_list[0]} 1-hop-cor = {cor_list[0]} 1-hop-acc = {ver_cor_list[0]}'
                info_dict['nll/2-hop-tot'] = f'2-hop-tot = {tot_list[1]} 2-hop-cor = {cor_list[1]} 2-hop-acc = {ver_cor_list[1]}'
                info_dict['nll/3-hop-tot'] = f'3-hop-tot = {tot_list[2]} 3-hop-cor = {cor_list[2]} 3-hop-acc = {ver_cor_list[2]}'
                info_dict['nll/4-hop-tot'] = f'4-hop-tot = {tot_list[3]} 4-hop-cor = {cor_list[3]} 4-hop-acc = {ver_cor_list[3]}'


        return cor,ver_cor,tot,cor_list,ver_cor_list,tot_list,info_dict


    def original_edit_step(self, batch, training: bool):
        self.model.train(training)
        self.original_model.train(training)

        # Do the edit
        start = time.time()
        edited_model, model_info = self.model.edit(batch["edit_inner"], batch["cond"])
        edit_time = time.time() - start

        l_total, l_edit, l_loc, l_base = 0, 0, 0, 0
        info_dict = {}
        # print(batch)

        ################ portability #################
        # print(batch['port'])
        if batch['port'] is not None and len(batch['port']) > 0:    
            
            port_acc = 0
            assert len(batch['port']) == 1, "batch['port'] should have only one element"
            for port in batch['port']:
                with torch.no_grad():

                    port_outputs = edited_model(port)
                    port_labels = port["labels"]
                    if not isinstance(port_outputs, torch.Tensor):
                        port_logits = port_outputs.logits
                    else:
                        port_logits = port_outputs
                    if port_logits.shape[1] > port_labels.shape[1]:
                        port_dict = self.model.edit_loss_fn(self.config, port_logits, port_labels)
                    else:
                        port_dict = self.model.edit_loss_fn(self.config, port_logits, port_labels[:, -port_logits.shape[1]-1:])
                    port_acc += port_dict["acc"].item()
                    info_dict['grad/port_pred_ids'] = port_dict['pred_ids']
                    info_dict['grad/port_targ_ids'] = port_dict['targ_ids']
            port_acc /= len(batch['port'])
            info_dict['port/acc'] = port_acc
        ################ portability #################
        
        info_dict = {**info_dict, **model_info}

        return l_total, l_edit, l_loc, l_base, info_dict




    def train_step(self, batch):

        # print
        l_total, l_edit, l_loc, l_base, info_dict = self.original_edit_step(
            batch, training=True
        )

        if self.global_iter > 0 and self.global_iter % self.config.accumulate_bs == 0:
            grad = torch.nn.utils.clip_grad_norm_(
                self.model.outer_parameters(),
                self.config.grad_clip,
                error_if_nonfinite=True,
            )
            info_dict['grad'] = grad.item()

            self.opt.step()
            self.opt.zero_grad()

            if self.lr_opt is not None:
                self.lr_opt.step()
                self.lr_opt.zero_grad()

                for lr_idx, lr in enumerate(self.model.edit_lrs):
                    info_dict[f'lr/lr{lr_idx}'] = lr.item()

        return info_dict

    def _inline_validation_log(self, step, stats, start_time, steps):
        elapsed = (time.time() - start_time) / (step + 1)
        prog = f"{step+1}/{steps}".ljust(20)
        #################################################################
        # inner_acc = f"{stats['inner/acc_val']:<12.5f}"
        # outer_acc = f"{stats['edit/acc_val']:<12.5f}"
        # image_acc = f"{stats['image_rephrase/acc_val']:<12.5f}"
        # loc_acc = f"{stats['loc/acc_val']:<12.5f}"
        # loc_image_acc = f"{stats['image_loc/acc_val']:<12.5f}"

        # LOG.info(
        #   f"Step {prog} outer_acc: {outer_acc} image_acc: {image_acc} inner_acc: {inner_acc} it_time: {elapsed:.4f} loc_acc: {loc_acc}, image_loc: {loc_image_acc}"
        # )
        #################################################################
        if 'port/acc_val' in stats:
            LOG.info(f"step {prog} port_acc: {stats['port/acc_val']:<12.5f} it_time: {elapsed:.4f}")
       
        if 'knowledge/acc_val' in stats:
            LOG.info(f"step {prog} knowledge_acc: {stats['knowledge/acc_val']:<12.5f} it_time: {elapsed:.4f}")

    def validate(self, steps=None, log: bool = False, result_name: str = None):
        if steps is None or steps > len(self.val_set):
            steps = len(self.val_set)

        if log:
            LOG.info(f"Beginning evaluation for {steps} steps...")
        averager = RunningStatAverager("val")

        start_time = time.time()
        if result_name is not None:
            port_result = []
        all_cor = all_tot = 0
        all_ver_cor = 0
        all_cor_list = [0,0,0,0]
        all_ver_cor_list = [0,0,0,0]
        all_tot_list = [0,0,0,0]
        fianl_info_dict = {}
        for val_step, batch in tqdm(enumerate(self.val_loader), total=steps, desc="Validation", ncols=100):
            if val_step >= steps:
                break
            
            if (log and (val_step) % self.config.log_interval == 0):
                self._inline_validation_log(
                    val_step, averager.average(), start_time, steps
                )
           
            if batch['port'] is None:
                continue

            item_cor,item_ver_cor,item_tot,item_cor_list,item_ver_cor_list,item_tot_list, info_dict = self.edit_step(batch, training=False)
            
            # print(f"item_cor: {item_cor}, item_ver_cor: {item_ver_cor}, item_tot: {item_tot}")
            # print(f"item_cor_list: {item_cor_list}, item_ver_cor_list: {item_ver_cor_list}, item_tot_list: {item_tot_list}")
            all_cor += item_cor
            all_ver_cor += item_ver_cor
            all_tot += item_tot
            all_cor_list = [x + y for x, y in zip(all_cor_list, item_cor_list)]
            all_ver_cor_list = [x + y for x, y in zip(all_ver_cor_list, item_ver_cor_list)]
            all_tot_list = [x + y for x, y in zip(all_tot_list, item_tot_list)]

            averager.add(info_dict) 

            # append write to txt file info_dict['port/acc']
            
            if result_name is not None:
                edit_inputs = batch['edit_inner']['text_input']
                # port_inputs = batch['port']['port_all_item']


                port_result.append({
                    'edit_input': edit_inputs,
                    # 'port_input': port_inputs,
                    'port_acc': info_dict['Acc'],
                    'port_hop_acc': info_dict['Hop-Acc'],
                    'port_1hop_tot': info_dict['nll/1-hop-tot'],
                    'port_2hop_tot': info_dict['nll/2-hop-tot'],
                    'port_3hop_tot': info_dict['nll/3-hop-tot'],
                    'port_4hop_tot': info_dict['nll/4-hop-tot'],

                }
                )
                print("-------------Current_all_result-------------------")
                print(f'Current_all_Acc = {all_cor / all_tot} ({all_cor} / {all_tot})')
                print(f'Current_all_Hop-Acc = {all_ver_cor / all_tot} ({all_ver_cor} / {all_tot})')
                print(f'Current_all_1-hop-tot = {all_tot_list[0]} 1-hop-cor = {all_cor_list[0]} 1-hop-acc = {all_ver_cor_list[0]}')
                print(f'Current_all_2-hop-tot = {all_tot_list[1]} 2-hop-cor = {all_cor_list[1]} 2-hop-acc = {all_ver_cor_list[1]}')
                print(f'Current_all_3-hop-tot = {all_tot_list[2]} 3-hop-cor = {all_cor_list[2]} 3-hop-acc = {all_ver_cor_list[2]}')
                print(f'Current_all_4-hop-tot = {all_tot_list[3]} 4-hop-cor = {all_cor_list[3]} 4-hop-acc = {all_ver_cor_list[3]}')


        fianl_info_dict['Acc'] = f'Acc = {all_cor / all_tot} ({all_cor} / {all_tot})'
        fianl_info_dict['Hop-Acc'] = f'Hop-Acc = {all_ver_cor / all_tot} ({all_ver_cor} / {all_tot})'
        fianl_info_dict['1-hop-tot'] = f'1-hop-tot = {all_tot_list[0]} 1-hop-cor = {all_cor_list[0]} 1-hop-acc = {all_ver_cor_list[0]}'
        fianl_info_dict['2-hop-tot'] = f'2-hop-tot = {all_tot_list[1]} 2-hop-cor = {all_cor_list[1]} 2-hop-acc = {all_ver_cor_list[1]}'
        fianl_info_dict['3-hop-tot'] = f'3-hop-tot = {all_tot_list[2]} 3-hop-cor = {all_cor_list[2]} 3-hop-acc = {all_ver_cor_list[2]}'
        fianl_info_dict['4-hop-tot'] = f'4-hop-tot = {all_tot_list[3]} 4-hop-cor = {all_cor_list[3]} 4-hop-acc = {all_ver_cor_list[3]}'  
        port_result.append({"final_info": fianl_info_dict})
        
        if result_name is not None:
            with open(f'results/results_multihop/{result_name}_port_hop{self.val_set.hop}.json', 'w') as f:
                json.dump(port_result, f, indent=2)
        

        if log:
            self._inline_validation_log(val_step, averager.average(), start_time, steps)
        elapsed = time.time() - start_time
        stats = averager.average()
        stats["eval_time/elapsed"] = elapsed
        stats["eval_time/average"] = elapsed / steps

        return stats
    
    def knowledge_qa(self, batch, training: bool):
        self.model.train(training)
        self.original_model.train(training)

        l_total, l_edit, l_loc, l_base = 0, 0, 0, 0
        info_dict = {}

        assert batch['port'] is not None, "portability edit must be provided"
        assert len(batch['port']) == 1, "batch['port'] should have only one element"

        knowledge = batch['port'][0]
        with torch.no_grad():
            knowledge_outputs = self.model(knowledge)
            knowledge_labels = knowledge["labels"]
            if not isinstance(knowledge_outputs, torch.Tensor):
                knowledge_logits = knowledge_outputs.logits
            else:
                knowledge_logits = knowledge_outputs
            if knowledge_logits.shape[1] > knowledge_labels.shape[1]:
                knowledge_dict = self.model.edit_loss_fn(self.config, knowledge_logits, knowledge_labels)
            else:
                knowledge_dict = self.model.edit_loss_fn(self.config, knowledge_logits, knowledge_labels[:, -knowledge_logits.shape[1]-1:])
            knowledge_acc = knowledge_dict["acc"].item()
        info_dict['knowledge/acc'] = knowledge_acc
        
        info_dict = {**info_dict, **{}}

        return l_total, l_edit, l_loc, l_base, info_dict
    
    def test_knowledge(self, steps=None, log: bool = False):
        from datetime import datetime
        cur_time = datetime.now().strftime("%y%m%d_%H%M%S")
        self.model.eval()

        if steps is None or steps > len(self.val_set):
            steps = len(self.val_set)

        if log:
            LOG.info(f"Beginning evaluation for {steps} steps...")
        averager = RunningStatAverager("val")

        start_time = time.time()
        for val_step, batch in tqdm(enumerate(self.val_loader), total=steps, desc="Validation", ncols=100):
            if val_step >= steps:
                break
            
            if (log and (val_step) % self.config.log_interval == 0):
                self._inline_validation_log(
                    val_step, averager.average(), start_time, steps
                )

            _, _, _, _, info_dict = self.knowledge_qa(batch, training=False)
            averager.add(info_dict) 

        if log:
            self._inline_validation_log(val_step, averager.average(), start_time, steps)
        elapsed = time.time() - start_time
        stats = averager.average()
        stats["eval_time/elapsed"] = elapsed
        stats["eval_time/average"] = elapsed / steps


        results_path = f"results/results_base_port/{cur_time}_{self.config.model_name}_port{self.val_set.hop}_questiontest.json"

        with open(results_path, "w") as f:
            json.dump(
                {"results": stats}, f
            )
            LOG.info("Wrote results to:")
            LOG.info(results_path)

        return stats

    
    def _inline_seq_log(self, step, stats, start_time, steps):
        elapsed = (time.time() - start_time) / (step + 1)
        prog = f"{step+1}/{steps}".ljust(20)
        inner_acc = f"{stats['inner/acc_val']:<12.5f}"
        outer_acc = f"{stats['edit/acc_val']:<12.5f}"
        image_acc = f"{stats['image_rephrase/acc_val']:<12.5f}"
        loc_acc = f"{stats['loc/acc_val']:<12.5f}"
        loc_image_acc = f"{stats['image_loc/acc_val']:<12.5f}"
        port_acc = f"{stats['port/acc_val']:<12.5f}"
        LOG.info(
          f"Step {prog} outer_acc: {outer_acc} image_acc: {image_acc} inner_acc: {inner_acc} it_time: {elapsed:.4f} loc_acc: {loc_acc}, image_loc: {loc_image_acc}, port_acc: {port_acc}"
        )


    def test_sequencial_step(self, batch, edited_model, base_logits, base_image_logits):
        info_dict = {}

        ##############################################################################
        with torch.no_grad():
            # inner
            inner_edit_outputs = edited_model(batch["edit_inner"])
            inner_batch_labels = batch["edit_inner"]["labels"]
            if not isinstance(inner_edit_outputs, torch.Tensor):
                inner_edit_logits = inner_edit_outputs.logits
            else:
                inner_edit_logits = inner_edit_outputs

            if inner_edit_logits.shape[1] > inner_batch_labels.shape[1]:
                inner_edit_dict = self.model.edit_loss_fn(self.config, inner_edit_logits, inner_batch_labels)
            else:
                inner_edit_dict = self.model.edit_loss_fn(self.config, inner_edit_logits, inner_batch_labels[:, -inner_edit_logits.shape[1]-1:])
            del inner_edit_outputs, inner_edit_logits
            torch.cuda.empty_cache()

            # text rephrase
            post_edit_outputs = edited_model(batch["edit_outer"])
            post_batch_labels = batch["edit_outer"]["labels"]
            if not isinstance(post_edit_outputs, torch.Tensor):
                post_edit_logits = post_edit_outputs.logits
            else:
                post_edit_logits = post_edit_outputs
            
            if post_edit_logits.shape[1] > post_batch_labels.shape[1]:
                post_edit_dict = self.model.edit_loss_fn(self.config, post_edit_logits, post_batch_labels)
            else:
                post_edit_dict = self.model.edit_loss_fn(self.config, post_edit_logits, post_batch_labels[:, -post_edit_logits.shape[1]-1:])
            del post_edit_outputs, post_edit_logits
            torch.cuda.empty_cache()

            # image rephrase
            post_image_edit_outputs = edited_model(batch["edit_outer_image"])
            post_image_batch_labels = batch["edit_outer_image"]["labels"]
            if not isinstance(post_image_edit_outputs, torch.Tensor):
                post_image_edit_logits = post_image_edit_outputs.logits
            else:
                post_image_edit_logits = post_image_edit_outputs

            if post_image_edit_logits.shape[1] > post_image_batch_labels.shape[1]:    
                image_rephrase_edit_dict = self.model.edit_loss_fn(self.config, post_image_edit_logits, post_image_batch_labels)
            else:
                image_rephrase_edit_dict = self.model.edit_loss_fn(self.config, post_image_edit_logits, post_image_batch_labels[:, -post_image_edit_logits.shape[1]-1:])
            del post_image_edit_outputs, post_image_edit_logits
            torch.cuda.empty_cache()

            # text loc
            post_base_outputs = edited_model(batch["loc"])
            if not isinstance(post_base_outputs, torch.Tensor):
                post_base_logits = post_base_outputs.logits
            else:
                post_base_logits = post_base_outputs
            post_base_logits_softmax_top_k = torch.topk(torch.nn.functional.softmax(post_base_logits, dim=-1), k=1, dim=-1).indices
            base_logits_softmax_top_k = torch.topk(torch.nn.functional.softmax(base_logits, dim=-1), k=1, dim=-1).indices
            del post_base_outputs, post_base_logits
            torch.cuda.empty_cache()

            # image loc
            post_image_base_outputs = edited_model(batch["loc_image"])
            if not isinstance(post_image_base_outputs, torch.Tensor):
                post_image_base_logits = post_image_base_outputs.logits
            else:
                post_image_base_logits = post_image_base_outputs
            post_image_base_logits_softmax_top_k = torch.topk(torch.nn.functional.softmax(post_image_base_logits, dim=-1), k=10, dim=-1).indices
            base_image_logits_softmax_top_k = torch.topk(torch.nn.functional.softmax(base_image_logits, dim=-1), k=10, dim=-1).indices
            del post_image_base_outputs, post_image_base_logits
            torch.cuda.empty_cache()

        info_dict['inner/acc'] = inner_edit_dict["acc"].item()
        info_dict['edit/acc'] = post_edit_dict["acc"].item()
        info_dict['image_rephrase/acc'] = image_rephrase_edit_dict["acc"].item()
        info_dict["loc/acc"] = sum(post_base_logits_softmax_top_k.view(-1) == base_logits_softmax_top_k.view(-1))/post_base_logits_softmax_top_k.view(-1).shape[0]
        info_dict["image_loc/acc"] = sum(post_image_base_logits_softmax_top_k.view(-1) == base_image_logits_softmax_top_k.view(-1))/post_image_base_logits_softmax_top_k.view(-1).shape[0]
        ##############################################################################

        ################ portability #################
        assert len(batch['port']) == 1, "batch['port'] exist and have only one element"
        port = batch['port'][0]
        with torch.no_grad():
            port_outputs = edited_model(port)
            port_labels = port["labels"]
            if not isinstance(port_outputs, torch.Tensor):
                port_logits = port_outputs.logits
            else:
                port_logits = port_outputs
            if port_logits.shape[1] > port_labels.shape[1]:
                port_dict = self.model.edit_loss_fn(self.config, port_logits, port_labels)
            else:
                port_dict = self.model.edit_loss_fn(self.config, port_logits, port_labels[:, -port_logits.shape[1]-1:])
            port_acc = port_dict["acc"].item()
        info_dict['port/acc'] = port_acc
        ################ portability #################

        return info_dict

    def test_sequencial(self, log: bool = False, test_num=200, gap_num=0):
        from datetime import datetime
        cur_time = datetime.now().strftime("%y%m%d_%H%M%S")
        self.model.train(True)
        # print(test_num)
        # print(gap_num)
        # exit()

        steps = test_num + gap_num
        if log:
            LOG.info(f"Beginning evaluation for {test_num} steps...")
        averager = RunningStatAverager("val")

        start_time = time.time()
        val_data_store = []
        base_logits_store = []
        base_image_logits_store = []
        pbar = tqdm(total=test_num, desc=f"Prepare", ncols=100)
        for val_step, batch in enumerate(self.val_loader):
            # print(len(batch))
            # exit()
            if val_step < test_num:
                val_data_store.append(batch)
                with torch.no_grad():
                    base_outputs = self.model(batch["loc"])
                    if not isinstance(base_outputs, torch.Tensor):
                        base_logits = base_outputs.logits
                    else:  
                        base_logits = base_outputs
                    base_logits_store.append(base_logits.clone().detach())
                        
                    base_image_outputs = self.model(batch["loc_image"])
                    if not isinstance(base_image_outputs, torch.Tensor):
                        base_image_logits = base_image_outputs.logits
                    else:
                        base_image_logits = base_image_outputs
                    base_image_logits_store.append(base_image_logits.clone().detach())
                pbar.update(1)
            else:
                break
        pbar.close()

        edited_model = self.model
        pbar = tqdm(total=gap_num+test_num, desc=f"Test Gap {gap_num}", ncols=100)
        for val_step, batch in enumerate(self.val_loader):
            edited_model, _ = edited_model.edit(batch["edit_inner"], batch["cond"], detach_history=True)
            if val_step >= gap_num:
                stored_batch = val_data_store.pop(0)
                stored_base_logits = base_logits_store.pop(0)
                stored_base_image_logits = base_image_logits_store.pop(0)
                info_dict = self.test_sequencial_step(stored_batch, edited_model, stored_base_logits, stored_base_image_logits)
                averager.add(info_dict)

            if (log and val_step >= gap_num and (val_step) % self.config.log_interval == 0):
                self._inline_seq_log(
                    val_step, averager.average(), start_time, steps
                )
            pbar.update(1)

            if len(val_data_store) == 0:
                break
        pbar.close()

        if log:
            self._inline_seq_log(val_step, averager.average(), start_time, steps)
        elapsed = time.time() - start_time
        stats = averager.average()
        stats["eval_time/elapsed"] = elapsed
        stats["eval_time/average"] = elapsed / steps

        results_path = f"results/results_sequencial/{cur_time}_{self.config.alg}_{self.config.model_name}_port{self.val_set.hop}_seqgap{gap_num}.json"

        with open(results_path, "w") as f:
            json.dump(
                {"results": stats}, f
            )
            LOG.info("Wrote results to:")
            LOG.info(results_path)

        return stats
    
    def edit_step_test_sequencial(self,edited_model, batch, training: bool):
        start = time.time()
        l_total, l_edit, l_loc, l_base = 0, 0, 0, 0
        info_dict = {}

        ################ portability #################
        cor = tot = 0
        ver_cor = 0
        cor_list = [0,0,0,0]
        ver_cor_list = [0,0,0,0]
        tot_list = [0,0,0,0]
        info_dict = {}
        edited_model.train(training)

        edited_model
        details = []  # 新增：用于保存每条的详细信息
        

        if batch['port'] is not None:
            # 遍历所有 hop
            for hop_name, port in batch['port'].items():
                tot += 1
                hop_num = int(hop_name.split('-')[0])  # 1-hop -> 1, 2-hop -> 2
                hop_idx = hop_num - 1  # index: 0, 1, 2, 3
                tot_list[hop_idx] += 1  # 统计总数
                with torch.no_grad():
                    found_ans = gold_path = False
                    for index, each_question in enumerate(port["text_input"]):
                        print(f"Processing question {index + 1}/{len(port['text_input'])} for {hop_name}...")
                        print(f"Question: {each_question}")

                        generated_ids = self.iterative_generate(
                            edited_model, each_question, port["image"], port["labels"], port['prompts_len'][index]
                        )
                        port_labels = port["labels"]
                        pred_token = self.tok.decode(generated_ids[0].tolist(), skip_special_tokens=True).strip()
                        targ_token = self.tok.decode(port_labels[0].tolist(), skip_special_tokens=True)
                        print(f"Predicted: {pred_token}, Target: {targ_token}")
                        print(each_question)

                        # 新增：保存详细信息
                        details.append({
                            "question": each_question,
                            "target": targ_token,
                            "output": pred_token
                        })
                        
                        if pred_token.strip() == "" or len(pred_token.strip())<=3 or not any(c.isalnum() for c in pred_token):
                            found_ans = False
                            continue
                        if any(pred_token.lower() in k.lower() for k in port['answer_ali']):
                            if not found_ans:
                                cor += 1
                                cor_list[hop_idx] += 1
                                found_ans = True
                                info_dict['nll/{0}hop_path_pred_ids'.format(hop_idx)] = port['ques_path_inputs']
                        
                        if found_ans==True:
                            if port['ques_path_inputs']==[]:
                                ver_cor += 1
                                ver_cor_list[hop_idx] += 1
                                break
                            else:
                                path_answer_predict = []
                                for i, sub_question in enumerate(port['ques_path_inputs']):
                                    print(sub_question)
                                    if index >= len(sub_question):
                                        new_index =0
                                    else:
                                        new_index = index    
                                    sub_question = sub_question[new_index]
                                    print("sub_question",sub_question)

                                    sub_answer_ids = self.tok.encode(port["port_ans_path"][i][0])
                                    sub_answer = torch.tensor([sub_answer_ids]).to(generated_ids.device)
                                    print("sub_answer",sub_answer)
                                    print(port["port_ans_path"][i][0])
                                    generated_sub_ids = self.iterative_generate(
                                        edited_model, sub_question, port["image"], sub_answer, []
                                    )
                                    sub_pred = self.tok.decode(generated_sub_ids[0].tolist(), skip_special_tokens=True).strip()
                                    path_answer_predict.append(sub_pred)
                                    # 新增：保存子问题
                                    details.append({
                                        "question": sub_question,
                                        "target": port["port_ans_path"][i][0],
                                        "output": sub_pred
                                    })

                                print("Path_answer_predict",path_answer_predict)
                                print(f"Gold Path: {port['port_ans_path']}")
                                gold_path = self.verify_gold_path(path_answer_predict, port["port_ans_path"])
                                if gold_path:
                                    ver_cor += 1
                                    ver_cor_list[hop_idx] += 1
                                    info_dict['nll/{0}hop_path_pred_ids'.format(hop_idx)] = path_answer_predict
                                    break
                info_dict['nll/{0}hop_path_ground_ids'.format(hop_idx)] = port['port_ans_path']

            print("--------------------Cureent_item--------------------------")
            if int(tot) == 0:
                    info_dict['Acc'] = 0.0
                    info_dict['Hop-Acc'] = 0.0
            else:
                info_dict['Acc'] = cor / tot
                info_dict['Hop-Acc'] = ver_cor / tot

            info_dict['nll/1-hop-tot'] = f'1-hop-tot = {tot_list[0]} 1-hop-cor = {cor_list[0]} 1-hop-acc = {ver_cor_list[0]}'
            info_dict['nll/2-hop-tot'] = f'2-hop-tot = {tot_list[1]} 2-hop-cor = {cor_list[1]} 2-hop-acc = {ver_cor_list[1]}'
            info_dict['nll/3-hop-tot'] = f'3-hop-tot = {tot_list[2]} 3-hop-cor = {cor_list[2]} 3-hop-acc = {ver_cor_list[2]}'
            info_dict['nll/4-hop-tot'] = f'4-hop-tot = {tot_list[3]} 4-hop-cor = {cor_list[3]} 4-hop-acc = {ver_cor_list[3]}'

        info_dict["details"] = details  # 新增：保存所有详细信息

        return cor,ver_cor,tot,cor_list,ver_cor_list,tot_list,info_dict
    
    def multi_edit_then_test_sequencial(self, result_name, edit_num=1, log=False,steps=None):
        from datetime import datetime
        cur_time = datetime.now().strftime("%y%m%d_%H%M%S")
        self.model.train(False)
        self.original_model.train(False)
        averager = RunningStatAverager("val")

        all_cor = all_ver_cor = all_tot = 0
        all_cor_list = [0, 0, 0, 0]
        all_ver_cor_list = [0, 0, 0, 0]
        all_tot_list = [0, 0, 0, 0]

        val_loader_iter = iter(self.val_loader)
        batch_idx = 0
        all_details=[]
        if steps is None or steps > len(self.val_set):
            steps = len(self.val_set)
            print(steps)
        


        
        while True:
            # 1. 收集edit_num个batch
            edit_data_store = []
            try:
                for _ in range(edit_num):
                    batch = next(val_loader_iter)
                    # print("this "*30)
                    # print(batch)
                    # exit()
                    edit_data_store.append(batch)
            except StopIteration:
                if not edit_data_store:
                    break  # 没有新数据了
            if not edit_data_store:
                break

            print(batch_idx)
               
            if batch_idx>= steps:
                break
            print("---------------------Editing{0}--------------------------".format(batch_idx))

            for batch in edit_data_store:
                edited_model, edit_model_info = self.model.edit(batch["edit_inner"], batch["cond"], detach_history=True)
                print(f"Edited model for batch {batch_idx + 1}/{len(edit_data_store)}")
                print(f"Edit model info: {edit_model_info}")
                # batch_idx += 1
            # 3. 统一测试
          
            # continue
            print("---------------------Testing edit results--------------------------")
            for i, batch in enumerate(edit_data_store):
                # print(f"Testing batch {i + 1}/{len(edit_data_store)}")
                # print("batch",batch)
                # print("****"*50)
                # exit()
                print(f"Testing batch {i + 1}/{len(edit_data_store)}")
                cor, ver_cor, tot, cor_list, ver_cor_list, tot_list, info_dict = self.edit_step_test_sequencial(edited_model,batch, training=False)
                all_cor += cor
                all_ver_cor += ver_cor
                all_tot += tot
                all_cor_list = [x + y for x, y in zip(all_cor_list, cor_list)]
                all_ver_cor_list = [x + y for x, y in zip(all_ver_cor_list, ver_cor_list)]
                all_tot_list = [x + y for x, y in zip(all_tot_list, tot_list)]
                averager.add(info_dict)
                all_details.append(info_dict.get("details", []))  # 收集每个batch的详细信息
                batch_idx += 1
                if log and (batch_idx % self.config.log_interval == 0):
                    LOG.info(f"Tested {batch_idx}")
                

            # 4. 重置模型为初始状态（如果需要），否则下一个10条是在当前模型基础上继续edit
            # 如果你希望每组10条都是基于原始模型edit，取消注释下一行
            # self.model = self._get_fresh_model()

                print(f"total {0} number sample all results".format(batch_idx*edit_num))
                print("-------------Current_all_result-------------------")
                
                print(f'Total_Acc = {all_cor / all_tot} ({all_cor} / {all_tot})')
                print(f'Total_Hop-Acc = {all_ver_cor / all_tot} ({all_ver_cor} / {all_tot})')

                print(f'Total_1-hop-tot = {all_tot_list[0]} 1-hop-cor = {all_cor_list[0]} 1-hop-acc = {all_ver_cor_list[0]}')
                print(f'Total_2-hop-tot = {all_tot_list[1]} 2-hop-cor = {all_cor_list[1]} 2-hop-acc = {all_ver_cor_list[1]}')
                print(f'Total_3-hop-tot = {all_tot_list[2]} 3-hop-cor = {all_cor_list[2]} 3-hop-acc = {all_ver_cor_list[2]}')
                print(f'Total_4-hop-tot = {all_tot_list[3]} 4-hop-cor = {all_cor_list[3]} 4-hop-acc = {all_ver_cor_list[3]}')

        stats = averager.average()
        stats["all_cor"] = all_cor
        stats["all_ver_cor"] = all_ver_cor
        stats["all_tot"] = all_tot
        stats["all_cor_list"] = all_cor_list
        stats["all_ver_cor_list"] = all_ver_cor_list
        stats["all_tot_list"] = all_tot_list
        if all_tot > 0:
            stats["Acc"] = all_cor / all_tot
            stats["Hop-Acc"] = all_ver_cor / all_tot
        else:
            stats["Acc"] = 0
            stats["Hop-Acc"] = 0

        # 可选：保存结果
        results_path = f"results/results_multi_edit_detail/{cur_time}_{self.config.alg}_{self.config.model_name}_multi_edit_number_{edit_num}.json"
        with open(results_path, "w") as f:
            json.dump({"results": stats}, f, indent=2)
            LOG.info("Wrote results to:")
            LOG.info(results_path)
        # 保存所有详细信息到一个文件
        details_path = f"results/results_multi_edit_detail/{cur_time}_{self.config.alg}_{self.config.model_name}_multi_edit_number_{edit_num}_details.json"
        with open(details_path, "w") as f:
            json.dump(all_details, f, indent=2)
            LOG.info("Wrote detailed results to:")
            LOG.info(details_path)
        return stats
