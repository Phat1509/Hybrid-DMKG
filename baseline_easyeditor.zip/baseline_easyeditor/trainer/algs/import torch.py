import torch
import types
import pytest
from .SERAC import SERAC_MULTI

# easyeditor/trainer/algs/test_SERAC.py


class DummyModel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.config = types.SimpleNamespace(hidden_size=8)
        self.Qformer = types.SimpleNamespace(config=types.SimpleNamespace(hidden_size=8))
        self.visual_encoder = torch.nn.Identity()
        self.ln_vision = torch.nn.Identity()
        self.query_tokens = torch.nn.Parameter(torch.randn(1, 2, 8))
        self.device = "cpu"
    def forward(self, *args, **kwargs):
        # Return a tensor or an object with .logits
        class Out:
            def __init__(self, logits):
                self.logits = logits
        if "return_dict" in kwargs and kwargs["return_dict"]:
            return Out(torch.randn(2, 3, 5))
        return torch.randn(2, 3, 5)
    def maybe_autocast(self):
        class DummyCtx:
            def __enter__(self): return self
            def __exit__(self, exc_type, exc_val, exc_tb): pass
        return DummyCtx()
    def state_dict(self, prefix="", keep_vars=False):
        return {"model.weight": torch.tensor([1.0])}
    def generate(self, *args, **kwargs):
        return torch.ones(1, 3)
    def encode_img(self, image):
        return torch.randn(image.shape[0], 2, 8), torch.ones(image.shape[0], 2, dtype=torch.long)
    def prompt_wrap(self, img_embeds, atts_img, prompt):
        return img_embeds, atts_img
    def prepare_inputs_labels_for_multimodal(self, input_ids, *args, **kwargs):
        # Return tuple as expected in code
        return (input_ids, None, kwargs.get("attention_mask", torch.ones_like(input_ids)), None, torch.randn(*input_ids.shape, 8), kwargs.get("targets", torch.ones_like(input_ids)))

class DummyClassifier(torch.nn.Module):
    def forward(self, **kwargs):
        # Simulate output for both BERT and sentence-transformers
        class Out:
            def __init__(self):
                self.last_hidden_state = torch.randn(2, 3, 8)
                self.pooler_output = torch.randn(2, 8)
                self.logits = torch.randn(2, 1)
        return Out()
    def modules(self):
        return []
    def state_dict(self, prefix="", keep_vars=False):
        return {}

class DummyReplacement(torch.nn.Module):
    def forward(self, *args, **kwargs):
        class Out:
            def __init__(self):
                self.logits = torch.randn(2, 3, 5)
        return Out()
    def named_parameters(self):
        return []
    def state_dict(self, prefix="", keep_vars=False):
        return {}

class DummyTokenizer:
    pad_token_id = 0
    sep_token = "[SEP]"
    eos_token = "<EOS>"
    def batch_decode(self, input_ids, skip_special_tokens=True):
        return ["dummy input"] * input_ids.shape[0]
    def __call__(self, texts, return_tensors=None, padding=None, add_special_tokens=None):
        # Return dummy tokenized output
        batch_size = len(texts) if isinstance(texts, list) else 1
        return {
            "input_ids": torch.ones(batch_size, 3, dtype=torch.long),
            "attention_mask": torch.ones(batch_size, 3, dtype=torch.long)
        }
    def to(self, device):
        return self
    def decode(self, input_ids):
        return "decoded"

@pytest.fixture
def serac_multi():
    config = types.SimpleNamespace(
        cls_class="DummyClassifier",
        cls_name="dummy",
        cross_attend=False,
        dropout=0.1,
        freeze=None,
        freeze_cntr=False,
        model_name="blip2",
        model_class="DummyModel",
        name="blip2",
        small_name="dummy",
        supervised=False,
        soft_weighting=True,
        dist_heads=1,
        bound_embeds=False,
        cos=False,
        square=False,
        lr=1e-3,
        lr_lr=1e-4,
        device="cpu",
        checkpoint_grad=False
    )
    model = DummyModel()
    classifier = DummyClassifier()
    classifier_tok = DummyTokenizer()
    replacement = DummyReplacement()
    replacement_tok = DummyTokenizer()
    return SERAC_MULTI(
        model=model,
        config=config,
        model_constructor=lambda: model,
        classifier=classifier,
        classifier_tok=classifier_tok,
        replacement=replacement,
        replacement_tok=replacement_tok,
        cache_inputs=[],
        cache_labels=[],
        scale=torch.tensor(1.0)
    )

def test_forward_no_cache(serac_multi):
    # No cache_inputs, should call base model
    x = torch.ones(2, 3, dtype=torch.long)
    out = serac_multi.forward({"input_ids": x, "labels": x})
    assert isinstance(out, torch.Tensor)
    assert out.shape == (2, 3, 5)

def test_forward_with_cache():
    # With cache_inputs, should run full logic
    serac = serac_multi()
    serac.cache_inputs = ["dummy"]
    serac.cache_labels = ["label"]
    # Patch run_classifier to return deterministic output
    serac.run_classifier = lambda *a, **k: (torch.tensor([0.6, 0.4]), torch.tensor([0, 0]), torch.zeros(2, 1))
    # Patch build_rep_input_tokens to return valid tensors
    def build_rep_input_tokens(kwargs, idxs, generation=False):
        return {
            "input_ids": torch.ones(2, 3, dtype=torch.long),
            "attention_mask": torch.ones(2, 3, dtype=torch.long),
            "labels": torch.ones(2, 3, dtype=torch.long)
        }
    serac.build_rep_input_tokens = build_rep_input_tokens
    x = torch.ones(2, 3, dtype=torch.long)
    out = serac.forward({"input_ids": x, "labels": x, "text_input": ["dummy"]}, return_logits_only=True)
    assert isinstance(out, torch.Tensor)
    assert out.shape == (2, 3, 5)

def test_attention_mask_dtype_handling():
    serac = serac_multi()
    serac.cache_inputs = ["dummy"]
    serac.cache_labels = ["label"]
    serac.run_classifier = lambda *a, **k: (torch.tensor([0.6, 0.4]), torch.tensor([0, 0]), torch.zeros(2, 1))
    # Patch build_rep_input_tokens to return attention_mask as float
    def build_rep_input_tokens(kwargs, idxs, generation=False):
        return {
            "input_ids": torch.ones(2, 3, dtype=torch.long),
            "attention_mask": torch.ones(2, 3, dtype=torch.float16),  # simulate bug
            "labels": torch.ones(2, 3, dtype=torch.long)
        }
    serac.build_rep_input_tokens = build_rep_input_tokens
    # Patch replacement to check attention_mask dtype
    class Replacement(torch.nn.Module):
        def forward(self, *args, **kwargs):
            attn_mask = kwargs.get("attention_mask")
            assert attn_mask.dtype == torch.bool or attn_mask.dtype == torch.long or attn_mask.dtype == torch.float16
            class Out:
                def __init__(self):
                    self.logits = torch.randn(2, 3, 5)
            return Out()
    serac.replacement = Replacement()
    x = torch.ones(2, 3, dtype=torch.long)
    out = serac.forward({"input_ids": x, "labels": x, "text_input": ["dummy"]}, return_logits_only=True)
    assert isinstance(out, torch.Tensor)
    assert out.shape == (2, 3, 5)