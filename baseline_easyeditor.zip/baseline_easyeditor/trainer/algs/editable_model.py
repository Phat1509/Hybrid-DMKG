import torch.nn as nn
from copy import deepcopy

from ..losses import masked_log_probs
from ..utils import _logits, shift_targets


class EditableModel(nn.Module):
    def __init__(self, model, config, model_constructor):
        super().__init__()

        self.model = model
        self.config = deepcopy(config)
        self.model_constructor = model_constructor

        def _edit_loss_fn(config, pred, targ):
            if 'minigpt4' in config.model_name.lower() or 'blip' in self.config.model_name.lower() or 'llava' in self.config.model_name.lower():
                return masked_log_probs(config, pred, targ, shift=True)
            elif 't5' in config.model_class.lower():
                return masked_log_probs(config, pred, targ)
            elif 'gpt' in config.model_class.lower():
                return masked_log_probs(config, pred, targ, shift=True)
            elif 'llama' in config.model_class.lower():
                return masked_log_probs(config, pred, targ, shift=True)
            elif 'internlm' in config.model_name.lower():
                return masked_log_probs(config, pred, targ, shift=True)
            elif 'chatglm' in config.model_name.lower():
                return masked_log_probs(config, pred, targ, shift=True)
            elif 'qwen' in config.model_name.lower():
                return masked_log_probs(config, pred, targ, shift=True)
            else:
                return masked_log_probs(config, pred, targ)

        self.edit_loss_fn = _edit_loss_fn
        self.loc_loss_fn = masked_log_probs

    def edit(self, batch, condition=None, detach_history=False):
        raise NotImplementedError

    def forward(self, *inputs, **kwargs):
        return _logits(self.model(*inputs, **kwargs))

    def outer_parameters(self):
        return self.parameters()
    

    def base_loss(self, input_ids, attention_masks, label_ids):
        pass

    def generate(self, *inputs, **kwargs):
        """
        使用底层模型生成输出。

        Args:
            input_ids: 输入的token id张量
            attention_mask: 可选，注意力mask
            generate_kwargs: 其他传递给模型generate的参数

        Returns:
            生成的输出
        """
        if hasattr(self.model, "generate"):
            return self.model.generate(*inputs, **kwargs)
        else:
            raise NotImplementedError("底层模型未实现generate方法")
